package pp2;

//method overloading
public class OverloadMethod {
	
public void area(int l,int b)
{
     System.out.println("Area of Rectangle : "+(l*b));
}
public void area(int r) 
{
     System.out.println("Area of Circle : "+(3.14*r*r));
}

public static void main(String args[])
{

OverloadMethod om=new OverloadMethod();
   om.area(6,5);
   om.area(10);  
}
}