package pp2;


//call by value
public class MethodCall {

int x=150;

int operation(int x) {
	x =x+100;
	return(x);
}

public static void main(String args[]) {
	MethodCall d = new MethodCall();
	System.out.println("Before operation value of data is "+d.x);
	d.operation(100);
	System.out.println("After operation value of data is "+d.x);
	}
}