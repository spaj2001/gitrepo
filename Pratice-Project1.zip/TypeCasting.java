package pp1;

public class TypeCasting {

	public static void main(String[] args) {
		
		//IMPLICIT TYPE CASTING
		System.out.println("**Implicit Type Casting**");
		char a='x';
		System.out.println("Value of char a: "+a);
		
		int b=a;
		System.out.println("Value of int b: "+b);
		
		float c=a;
		System.out.println("Value of float c: "+c);
		
		long d=a;
		System.out.println("Value of long d: "+d);
		
		double e=a;
		System.out.println("Value of double e: "+e);
		
				
		
		
		System.out.println("**Explicit Type Casting**");
		//EXPLICIT TYPE CASTING
		
		long x=127832871344739L;
		int y=(int)x;
		System.out.println("Value of long x: "+x);
		System.out.println("Value of int y: "+y);
		
	}
}

